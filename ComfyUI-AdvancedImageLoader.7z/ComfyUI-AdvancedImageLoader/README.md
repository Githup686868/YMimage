# ComfyUI Advanced Image Loader

一个用于 ComfyUI 的高级图片加载节点，支持按顺序批量加载文件夹中的图片。

## 功能

- **顺序加载**：自动扫描文件夹中的图片并按文件名排序。
- **批量控制**：可以设置每次运行加载的图片数量（Batch Size）。
- **状态保持**：节点会记住当前的加载进度，连续运行（如“Auto Queue”）时会自动加载下一批。
- **手动控制**：支持手动指定起始索引，方便跳转或重置。
- **触发器**：带有 Trigger 开关，方便控制节点启用/禁用。
- **自动调整**：如果批次中图片尺寸不一致，会自动调整大小以匹配第一张图片（避免报错）。
- **文件名输出**：输出当前批次加载的图片文件名列表。

## 安装方法

1. 将 `ComfyUI-AdvancedImageLoader` 文件夹复制到你的 ComfyUI 安装目录下的 `custom_nodes` 文件夹中。
   例如：`ComfyUI/custom_nodes/ComfyUI-AdvancedImageLoader`
2. 重启 ComfyUI。

## 使用说明

1. 在节点列表中找到 `Advanced Image Loader (Sequential)`（通常在 `advanced/loaders` 分类下）。
2. **image_folder**: 输入包含图片的文件夹绝对路径。
3. **load_limit**: 设置每次加载几张图片。
4. **start_index**: 
   - 设置为 `0` 时（默认）：自动模式。节点会自动记住上次加载的位置，继续加载下一批。
   - 设置为 `1` 或其他正整数时：手动模式。强制从该序号（第1张、第2张...）开始加载。
5. **trigger**: 开启时正常工作，关闭时停止加载。

## 输出

- **IMAGE**: 加载的图片批次 (Tensor)。
- **image_names**: 当前批次加载的所有图片文件名（字符串，多张图片时以换行符分隔）。
- **current_batch_info**: 当前加载进度的文本描述。
- **done**: 布尔值，当所有图片加载完毕时为 True。
