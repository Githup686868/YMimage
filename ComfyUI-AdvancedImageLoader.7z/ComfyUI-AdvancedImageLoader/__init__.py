from .advanced_image_loader import AdvancedImageLoader

NODE_CLASS_MAPPINGS = {
    "AdvancedImageLoader": AdvancedImageLoader
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AdvancedImageLoader": "Advanced Image Loader (Sequential)"
}

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']
