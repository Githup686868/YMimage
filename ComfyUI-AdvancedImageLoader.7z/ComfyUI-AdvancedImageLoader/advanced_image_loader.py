import os
import torch
import numpy as np
from PIL import Image, ImageOps

class AdvancedImageLoader:
    """
    一个按顺序并可控的批量图片加载节点。
    功能:
    - 自动按文件名排序加载。
    - 可设置每批加载上限。
    - 可手动指定开始加载的索引。
    - 内部保持状态，支持连续批量加载。
    - 提供进度信息和完成状态输出。
    """
    # 类变量，用于在节点实例之间保持状态
    current_index = 0
    image_list = []
    target_folder = ""

    @classmethod
    def INPUT_TYPES(s):
        """定义节点的输入参数。"""
        return {
            "required": {
                "image_folder": ("STRING", {"default": "", "multiline": False, "placeholder": "输入图片文件夹路径..."}),
                "load_limit": ("INT", {"default": 1, "min": 1, "max": 100, "step": 1, "display": "number"}),
                "start_index": ("INT", {"default": 0, "min": 0, "max": 999999, "step": 1, "display": "number"}),
            },
            "optional": {
                "trigger": ("BOOLEAN", {"default": True, "label_on": "加载", "label_off": "停止", "display": "toggle"}),
            }
        }

    RETURN_TYPES = ("IMAGE", "STRING", "STRING", "BOOLEAN",)
    RETURN_NAMES = ("IMAGE", "image_names", "current_batch_info", "done",)
    FUNCTION = "load_images_sequentially"
    CATEGORY = "advanced/loaders"
    TITLE = "Advanced Image Loader (Sequential)"

    def load_images_sequentially(self, image_folder, load_limit, start_index, trigger=True):
        """
        核心执行函数，负责按顺序加载图片。
        
        Args:
            image_folder (str): 包含图片的文件夹路径。
            load_limit (int): 每批加载的最大图片数量。
            start_index (int): 手动指定的开始索引。0表示使用内部状态继续。
            trigger (bool): 一个触发器，用于手动控制节点的执行。

        Returns:
            tuple: 包含 (图片张量, 图片名称列表字符串, 批次信息字符串, 是否加载完成)。
        """
        # 如果触发器关闭，则不执行任何操作
        if not trigger:
            # 返回一个空的 1x1 黑色图像作为占位符，避免后续节点报错
            empty_img = torch.zeros((1, 64, 64, 3), dtype=torch.float32)
            return (empty_img, "", "等待触发...", False)

        # 检查文件夹路径是否有效
        if not os.path.isdir(image_folder):
            print(f"[AdvancedImageLoader] 错误：文件夹 '{image_folder}' 不存在。")
            empty_img = torch.zeros((1, 64, 64, 3), dtype=torch.float32)
            return (empty_img, "", f"文件夹不存在: {image_folder}", True)

        # 如果文件夹变更或图片列表为空，则重新扫描和排序
        if image_folder != self.target_folder or not self.image_list:
            self.target_folder = image_folder
            # 获取所有支持的图片文件并排序
            supported_formats = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".gif"}
            try:
                self.image_list = sorted([
                    f for f in os.listdir(image_folder) 
                    if os.path.splitext(f)[1].lower() in supported_formats
                ])
            except Exception as e:
                print(f"[AdvancedImageLoader] 扫描文件夹失败: {e}")
                self.image_list = []
                
            self.current_index = 0 # 重置索引

        total_images = len(self.image_list)
        if total_images == 0:
            empty_img = torch.zeros((1, 64, 64, 3), dtype=torch.float32)
            return (empty_img, "", "文件夹中没有找到支持的图片。", True)

        # 确定本次加载的起始位置
        # 如果 start_index 为 0，则使用 self.current_index (继续模式)
        # 如果 start_index >= 1，则强制从该索引(1-based)开始
        if start_index > 0:
             # 将 1-based index 转换为 0-based index
            self.current_index = start_index - 1
        
        # 边界检查
        if self.current_index >= total_images:
             empty_img = torch.zeros((1, 64, 64, 3), dtype=torch.float32)
             return (empty_img, "", f"加载完成！共处理 {total_images} 张图片。", True)

        # 计算本次加载的结束位置
        end_index = min(self.current_index + load_limit, total_images)

        # 准备加载当前批次的图片
        batch_images = []
        batch_filenames = []
        batch_info = f"已加载 {self.current_index + 1} - {end_index} / {total_images} 张"

        print(f"[AdvancedImageLoader] 正在加载: {batch_info}")

        # 遍历并加载图片
        for i in range(self.current_index, end_index):
            filename = self.image_list[i]
            image_path = os.path.join(self.target_folder, filename)
            try:
                # 标准 ComfyUI 图片加载流程
                img = Image.open(image_path)
                img = ImageOps.exif_transpose(img)
                if img.mode == 'I':
                    img = img.point(lambda i: i * (1 / 255))
                img = img.convert("RGB")
                img_np = np.array(img).astype(np.float32) / 255.0
                img_tensor = torch.from_numpy(img_np)[None,]
                batch_images.append(img_tensor)
                batch_filenames.append(filename)
            except Exception as e:
                print(f"[AdvancedImageLoader] 加载图片失败 {image_path}: {e}")

        # 更新下一次的起始索引
        self.current_index = end_index

        # 将张量列表合并
        if batch_images:
            # 检查是否所有图片尺寸一致，如果不一致可能需要处理，这里简单处理为：如果尺寸不一致，ComfyUI可能会报错或者需要resize
            # 为了简单起见，我们假设用户的一批图片尺寸一致，或者接受torch.cat的报错
            try:
                image_tensor = torch.cat(batch_images, dim=0)
            except RuntimeError:
                # 尺寸不一致时的回退：调整到第一张图片的大小
                print("[AdvancedImageLoader] 警告：批次中图片尺寸不一致，正在调整...")
                first_shape = batch_images[0].shape # (1, H, W, C)
                target_h, target_w = first_shape[1], first_shape[2]
                resized_batch = []
                for b_img in batch_images:
                    if b_img.shape[1:] != first_shape[1:]:
                        # 转换为 (C, H, W) 进行 interpolate
                        b_img_permuted = b_img.permute(0, 3, 1, 2)
                        b_img_resized = torch.nn.functional.interpolate(b_img_permuted, size=(target_h, target_w), mode="bilinear", align_corners=False)
                        # 转回 (1, H, W, C)
                        b_img_final = b_img_resized.permute(0, 2, 3, 1)
                        resized_batch.append(b_img_final)
                    else:
                        resized_batch.append(b_img)
                image_tensor = torch.cat(resized_batch, dim=0)

            done = self.current_index >= total_images
            # 组合文件名为字符串，用换行符分隔，方便查看
            filenames_str = "\n".join(batch_filenames)
            return (image_tensor, filenames_str, batch_info, done)
        else:
            # 如果当前批次一张都没加载成功
            empty_img = torch.zeros((1, 64, 64, 3), dtype=torch.float32)
            return (empty_img, "", "当前批次加载失败。", self.current_index >= total_images)

# 这一行在 ComfyUI 加载时不需要，但在作为独立脚本测试时可以保留
if __name__ == "__main__":
    pass
